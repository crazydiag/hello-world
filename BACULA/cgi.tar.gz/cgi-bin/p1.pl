#!/usr/bin/env perl

use DBI;
use Net::DNS;
use Net::IP;
#use strict;
#use warnings;
use Time::Local;
our $setjob ='';
our @jobs ;
our $i;
our $key;
our $value;
our $clntvalue;
our $clntday;
our %fileset;
our %clntset;
our $setfileset;
our $namefileset;
our %conf;
our %excludeconf;
our %retdayset;
our %clientset;
our $setclntset ='';

#$host="localhost";
#$database="bacula";
#$user="root";
#$psw="";


sub parse {

    glob %conf;
	glob %excludeconf;
	my $conf_array=shift;
	glob @jobs;
	glob $namefileset;
	glob %fileset;
	glob %clntset;
	glob %retdayset;
	glob %clientset;
	my $level=shift;
	my $cntOpen=0;								# Счетчик открытых скобок
	my $name="";								# Имя параметра или блока
	my $blockBody="";							# Тело блока
	my $paramValue="";							# Значение параметра
	my $inQuotes=0;								# Флаг открытой кавычки
	my $inBlock=0;								# Флаг открытого блока
	my $inParam=0;								# Флаг открытого параметра
	my $inComment=0;							# Флаг нахождения в комментарии
	my $tmpname="";                             # Временное значение имени джоба для заполнения массивов
	my $prev_char="";  	# Запоминаем предыдущий символ
	my $tmpfilesetname="";
	my $ind=0;
	
	glob $setjob ;
	glob $setfileset ;
	glob $setclntset;
	while($conf_array=~/(.)/gs){
		my $char=$1;
	
		# Найден '=' не в блоке, не в комментарии, не в кавычках
		if(($char eq "=") && (!$inQuotes) && (!$inBlock) && (!$inComment)){
			# До этого был найден '=' значит это является значением параметра
			if($inParam){
				$paramValue.=$char;
#				print "$paramValue \n";
			}
			# До этог не было найдено ни одного '=' значит имени параметра
			else{
				$inParam=1;
				$paramValue="";
				$name=~s/(^\s+|\s+$)//g;
##				print $name;
			}
		}
		# Найден '#' не в комментарии, не в кавычках
		elsif(($char eq "#") && (!$inComment) && (!$inQuotes)){
			$inComment=1;
			# Если до этого было значение параметра
			if($inParam){
				$paramValue=~s/(^\s+|\s+$)//g;
				for(my $p=0;$p<=$level;$p++){
##					print " ";
				}
##				print "  Найден параметр [$name] = [$paramValue]";
				$name="";
				$inParam=0;
			}
		}
		# Усли найден '\n' или ';' не в кавычках, не в комментарии и является параметром значения
			elsif(($char eq ";") && (!$inQuotes) && $inParam && (!$inComment)){
			$paramValue=~s/(^\s+|\s+$)//g;
###			print "$paramValue \n";
			for(my $p=0;$p<=$level;$p++){
###				print " ";
			}
##			print "  Найден параметр [$name] = [$paramValue]\n";
			$inParam=0;
			$name="";
			$inComment=0;
		}
		# Если найден '{' не в кавычках, не в комментарии это начало блока
		elsif(($char eq "{") && (!$inQuotes) && (!$inComment)){
			if($cntOpen==0){
				$blockBody="";
				$inBlock=1;
				$name=~s/(^\s+|\s+$)//g;

				
				
###############################################################################################				
			if($name eq "Job"){
			$setjob=1;
			}
			else{
			$setjob=0;
			}
			if($name eq "Client"){
			$setclntset=1;
#			print " ++++++++++$setjob++++++++$setclntset++++$name+++++++++++++++++++++++++++++ \n";
			}
			else{
			$setclntset=0;
#			print " ----------$setjob-----$setclntset-----$name--------------------------------\n";
			}
			if(($name eq "FileSet") || ($name eq "Include") || ($name eq "Options")) {
			$setfileset=1;
			}
			else{
			$setfileset=0;
			}
			if(($name eq "Exclude")) {
			$setfileset=11;
#			print "++++++++++++++++++++++++++++++++$setfileset +++++++++++++++++++++++++++";
			}


			}
			
#			
##############################################################################################			
			else{
				$blockBody.=$char if($inBlock);
			}
			$cntOpen++;
		}
		# Если найден '}' не в кавычках, не в комментарии и в блоке
		elsif(($char eq "}") && (!$inQuotes) && $inBlock && (!$inComment)){
				if($cntOpen==1){
					for(my $p=0;$p<=$level;$p++){
###						print " ";
					}
##					print "Найден блок [$name]\n";
					parse($blockBody,$level+5);
					$inBlock=0;
					$name="";
				}
				else{
					$blockBody.=$char if($inBlock);
				}
				$cntOpen--;
		}
		elsif(($char eq "\"") && ($prev_char ne "\\") && (!$inComment)){
			if($inQuotes ==0){
				$inQuotes=1;
			}
			else{
				$inQuotes=0;
			}
			if($inBlock){
				$blockBody.=$char;
			}
			else{
				$paramValue.=$char;
			}
		}
		else{
			$prev_char=$char;
			# Любой другой символ записываем в зависимости от нахождения 
			if(!$inComment){
				if($inBlock){
					$blockBody.=$char;
				}
				elsif($inParam){
					$paramValue.=$char;
				}
				else{
					$name.=$char;
				}
			}
			if($char eq "\n" && (!$inQuotes)){
				$inComment=0 if($inComment);
				if($inParam){
					$paramValue=~s/(^\s+|\s+$)//g;

					for(my $p=0;$p<=$level;$p++){

					}
###################################################################################################################################
if(($setjob ==1) && ($name eq "Name")){
#print "job--$setjob---$name----- $paramValue \n";
#print "++++++++++++++++++++$paramValue+++++++++++++++++++++++++++\n";
push (@jobs,$paramValue);
$tmpname = $paramValue;

}
if(($setclntset ==1) && ($name eq "Name")){

$tmpname = $paramValue;

}
if(($setjob ==1) && ($name eq "Client")){
#print "$tmpname--$setjob---$name----- $paramValue \n";
%clntset = (%clntset,$tmpname,$paramValue);
#print @jobworks."+_+_+_+_";
}
if(($setjob ==1) && ($name eq "FileSet")){
#print "$tmpname--$setjob---$name----- $paramValue \n";
%fileset = (%fileset,$tmpname,$paramValue);
#print @jobworks."+_+_+_+_";
}
if(($setfileset ==1) && ($name eq "Name")){
$namefileset = $paramValue;
$ind=0;

}

if(($setfileset ==1) && ($name eq "File")){

$conf{$namefileset}[$ind]=$paramValue;
$ind+=1;
}
if(($setfileset ==11) && ($name eq "File")){

#$ind+=1;
#print "$ind----$setfileset--$namefileset-------$name--------$paramValue \n";
##############print "EXCLUDE --+$namefileset+------$name--------$paramValue \n";
$excludeconf{$namefileset}[$ind]=$paramValue;
$ind+=1;
}
if(($setclntset ==1) && ($name eq "Address")){
#print "$tmpname--$setjob---$name----- $paramValue \n";
%clientset = (%clientset,$tmpname,$paramValue);
#print @jobworks."+_+_+_+_";
}
if(($setclntset ==1) && ($name eq "File Retention")){
#print "$tmpname--$setjob---$name----- $paramValue \n";
%retdayset = (%retdayset,$tmpname,$paramValue);
#print @jobworks."+_+_+_+_";
}





#print "$setjob---$setclntset--$name----- $paramValue \n";
####################################################################################################################################					
#				print "  Найден параметр [$name] = [$paramValue]\n";
					$inParam=0;
					$name="";
				}
				$blockBody.=$char if($inBlock);
			}
		}
	
	}
	
}

sub read_file{
	my $file=shift;
	my $text;

	open my $conf,"<$file" || (print "Cannot open File $file"  && return "");
	while(<$conf>){
		if(/^@\|"([^"]*)"/){
			open my $com, "$1|";
			while(my $line=<$com>){
				$line=~s/^@//g;
				$text.=read_file($line);
			}
			next;
		}
		if(/^@(.*)$/){
			$text.=read_file($1);
			next;
		}
		else{
			$text.=$_;
		}
	}
	close $conf;
	return $text;
}


my $conf_file="/usr/local/etc/bacula-dir.conf";
my $Data;
my $mmonth;
my $mday;
my $myear;
my $conf_array=read_file($conf_file);
my %arrip;
my $clnt;
my $clntip;

my $dbh=DBI->connect('DBI:mysql:bacula', 'root', '') || die "Could not connect to database: $DBI::errstr";
###my $sth=$dbh->prepare("SELECT EndTime FROM `Job` where Name = 'prociondbackup' and JobStatus='T' order by EndTime desc LIMIT 1");
###$sth->execute();
###my @results = $sth->fetchrow_array();
###$sth->execute();
#$results[0]=~ m/\d+\-\d+\-\d+/;
#my $mmonth=$&;
###print "$results[0]\n\n\n\n";
### while ($results[0] =~ m/\d+\-(\d+)-(\d+)/g) {
### $mmonth=$1;
### $mday=$2;
 # print "$2: $1\n";
###  }
###  print " Month is $mmonth, Day is $mday \n";
###$sth->finish();
#####################################################################################
parse($conf_array,1);
open(FIL,"getent hosts|");
while(<FIL>)
{

chomp;

m/(\S+)\s+(\S+)/;

%arrip = (%arrip,$2,$1);
}
close FIL;
#while(($key,$value) = each %arrip){
#print "$key => $value\n";
#};
my @timeData = localtime(time);
my $mepoch = timelocal(0,0,0,$timeData[3],$timeData[4],$timeData[5]);
#my $testepoch = time();
#print "Today is $timeData[4].$timeData[3] ----- $testepoch -------- $mepoch \n";
#####################################################################################
##for ($i =$[; $i <= $#jobs; $i++)
##
##            {
##
##                        print @jobs[$i]."\n";
##
##            }
#while(($key,$value) = each %retdayset){
#print "$key => $value\n";
#};
####foreach $key (sort keys %fileset) {
####$value = $fileset{$key};
####print "$key ++++++++++++=> $value\n";
####my $ar = $conf{$value} ;
####foreach my $re (@$ar) {
####    print "\t$re\n" ;
####}
# Или без использования лишней переменной $value:
# print "$key => $hash{$key}\n";
####}
#foreach my $key (keys(%excludeconf)) {
#print "KEY=$key\n" ;
#my $ar = $excludeconf{$key} ;
#foreach my $re (@$ar) {
#    print "\t$re\n" ;
#} 
#}
 print "Content-Type:text/html; charset=UTF-8\n\n";
 print "<html>\n<head>\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1251\">\n";
 print "<title>Jobs and Files</title>\n</head>\n<body>\n";

open(FIL,"/usr/local/www/cgi-bin/css.txt");
while(<FIL>)
{
print $_;

}
close FIL;
open(FIL,"/usr/local/www/cgi-bin/script.txt");
while(<FIL>)
{
print $_;

}
close FIL;

 print "<table class=\"sort\" aligh=\"center\">\n<thead>\n";
 print "<tr><td>JOB NAME</td>\n<td>FileSet</td>\n<td>Client</td>\n<td>Client IP</td>\n<td>Backup Files</td><td>Excluded Files</td><td>Last Fullbackup Time</td><td>Num Days</td><td>Limit Days</td><td>Full Backup Size GiB</td></tr>\n</thead>\n";
 print "<tbody>\n";
foreach $key (sort keys %fileset) {
$value = $fileset{$key};
$clntvalue = $clntset{$key};
$clnt = $clientset{$clntvalue};
$clntip = $arrip{$clnt};
$clntday = $retdayset{$clntvalue};
if ( $clntip eq undef ) {
 
$clntip = resolv($clnt);
#$clntip = "$clntip+++++++$clnt++++++++" ;
}
#$clntday =~ s/(\d+)\s\w+/$1/;
my $ar = $conf{$value} ;
 print "<tr>\n";
 print "<td>$key</td>\n<td>$value</td><td>$clnt</td><td>$clntip</td>\n";
 print "<td>";
 foreach my $re (@$ar) {
    print "$re<BR>" ;
}
 print "</td>\n";
 #print "</tr>\n";
 print "<td>\n";
if (exists ($excludeconf{$value})) {
 my $rar = $excludeconf{$value} ;
 #print " +_+_+_+_+_YYYES+_+_+_+_+_+_+";
 foreach my $rer (@$rar) {
    print "$rer<BR>" ;
}
}
else
{
 print "&nbsp;";
}
print "</td>\n";

$key=~ s/\"//g;

my $sth=$dbh->prepare("SELECT EndTime FROM `Job` where Name = \'$key\' and JobStatus='T' and Level='F' order by EndTime desc LIMIT 1");
$sth->execute();
my $sth1=$dbh->prepare("SELECT JobBytes FROM `Job` where Name = \'$key\' and JobStatus='T' and Level='F' order by EndTime desc LIMIT 1");
$sth1->execute();
my @results = $sth->fetchrow_array();
my @results1 = $sth1->fetchrow_array();
while ($results[0] =~ m/(\d+)\-(\d+)-(\d+)/g) {
 $myear=$1;
 $mmonth=$2;
 $mday=$3;
# print "$2: $1\n";
  }
my $myepoch = timelocal(0,0,0,$mday,$mmonth-1,$myear-1900);
my $gsize = sprintf("%.4f",@results1[0]/1024000000);
$myepoch = ($mepoch - $myepoch)/86400;
print "<td>$mday\.$mmonth\.$myear</td><td>$myepoch</td><td>$clntday</td><td>$gsize</td>\n";
$sth->finish();
$sth1->finish();
 print "</tr>\n";
}
print "</tbody>\n";
 print "</table>\n</body>\n</html>";
 $dbh->disconnect(); 
 
sub resolv
{
my $rr;
my @dnsiparr;
my $res = Net::DNS::Resolver->new();

########### WEBSITE A RECORD  ###################

my $a_query = $res->search($_[0]);
 
#print "Website IP Address (A Record)...\n";
 
  if ($a_query) {
      foreach my $rr ($a_query->answer) {
#	   print $rr->address, "\n";
          next unless $rr->type eq "A";
		  push (@dnsiparr,$rr->address);
		  return @dnsiparr[0];
#         print $rr->address, "\n";
      }
 }
 #return @dnsiparr;
 #return @dnsiparr[0];
  }
  